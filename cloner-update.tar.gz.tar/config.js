module.exports = {
  token: 'توكن بوت',
  clientId: ' ايدي بوت',
  parentId: 'كاتيجوري',
  probot_ids: ['بروبوت ايدي'],
  recipientId: 'البنك',
  price: 15000,

};

